package com.mycompany.assignment1scdparta;

import java.util.List;

class Magazine extends Item{
 
    //constructor
    public Magazine(String title,String CompanyName,List<String> AuthorsList)
    {
        super.SetId();
        super.SetTitle(title);
        super.setAuthorsList(AuthorsList);
        super.setCompanyName(CompanyName);
    }
    @Override
    public void DisplayInfo()
    {
        System.out.print("Magazine");
        super.DisplayInfo();
        System.out.println(" published by "+this.getCompanyName()+" ( Authors : "+this.getAuthorsList()+")"+" and Popularity Count : "+this.getPopularityCount());
            
    }
    @Override
    public int CalculateCost() {
     
        this.SetMagazineCost(this.GetId()*20);
        super.CalculateCost();
        System.out.println(" Rs."+this.getMagazinecost());
        return this.getMagazinecost();
    }
}
