package com.mycompany.assignment1scdparta;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
public class Library {
     /***********************PART F********************/
    Map<String,String> BorrowerList=new HashMap<>();//BorrowerList
    /***********************PART D********************/
    void getDetails(Item a)
    {
        a.DisplayInfo();
    }
    /***********PART C***********/
    List<Item> BooksList=new ArrayList<>();//BooksList
    // add item 
    void AddItem(Item obj)
    {
        BooksList.add(obj);
    }
    // file loading while execution
    void LoadingFile() throws FileNotFoundException
    {
        File file=new File("data.txt");//Loading Books from file
        Scanner read= new Scanner(file);
        read.useDelimiter(",");
        while(read.hasNextLine())//Till the last line
        {
          String line=read.nextLine();//line by line 
          String []value=line.split(",");
          int opt=Integer.parseInt(value[0]);
          if(opt==1)
          {
              Book BookData=new Book(value[1],value[2],Integer.parseInt(value[3]));
              AddItem(BookData);//adding in my list 
          } 
          else if(opt==2)
          {
              List<String> AuthorsList=new ArrayList<>();
              String title=value[1];
              String authorname;
              int i=0;
              for(i=2;i<value.length;i++)
              {
                  authorname=value[i];
                  int len=authorname.length();
                  if(authorname.charAt(len-1)== '.')
                  {
                      authorname=authorname.substring(0, len-1);
                      AuthorsList.add(authorname);
                      i++;
                      break;
                  }
                  else
                  {
                  AuthorsList.add(authorname);   
                  }
              }
              Magazine MagazineData=new Magazine(title,value[i],AuthorsList);
              AddItem(MagazineData);
          }
          else if(opt==3)
          {
              Newspaper NewspaperData=new Newspaper(value[1],value[2],value[3]);
              AddItem(NewspaperData);
          }
        }
    }
    
 // view Items function
    void ViewAllItems()
    {
        System.out.println("All Items in the Library are : ");
        for(Item data:BooksList)
        {
            if (data instanceof Book)
            {
             data.DisplayInfo();
            }
            else if(data instanceof Newspaper)
            {
            data.DisplayInfo();
            }
            else if (data instanceof Magazine)
            {
           
               data.DisplayInfo();
            
            }
        }
    }
//View Item By Id
    void ViewItemById(int Id)
    {
        for(Item data:BooksList)
        {
            if(Id==data.GetId())
            {
                if (data instanceof Book)
                {
                data.DisplayInfo();
                return;
                }
                else if(data instanceof Newspaper)
                {
                data.DisplayInfo();
                return;
                }
                else if (data instanceof Magazine)
                {
                data.DisplayInfo();
                return;
                }
            }          
        }
        System.out.println("Invalid ID"); 
    }
//Edit Title
    void EditTitle(Item data)
    { 
        Scanner input=new Scanner(System.in);
        String value; 
        System.out.print("Enter the new title of the book : ");
        value=input.nextLine();
        data.SetTitle(value);      
    }
 //Edit Author
    void EditAuthor(Item data)
    { 
        Scanner input=new Scanner(System.in);
        String value; 
        System.out.print("Enter the new author of the book : ");
        value=input.nextLine();
        data.SetAuthor(value);      
    }
//Edit YearOfPublication of Book
    void EditYearOfPublication(Item data)
    { 
        Scanner input=new Scanner(System.in);
        String value; 
        System.out.print("Enter the new year of publication of the book : ");
        int valuee=input.nextInt();
        if(valuee>2023||valuee<1)
        {
            System.out.println("Invalid entry");
        }
        else
        {
        data.SetYear(valuee);   
        }   
    }
//Edit DateOfPublication
    void EditDateOfPublication(Item data)
    { 
        Scanner input=new Scanner(System.in);
        String value; 
        String valuee=dateofpublication();
        data.setDateofPublication(valuee);     
    }
//Edit Company Name
    void EditCompanyName(Item data)
    { 
        Scanner input=new Scanner(System.in);
        String value; 
        System.out.print("Enter the company name : ");
        String valuee=input.nextLine();
        data.setCompanyName(valuee);     
    }
//Add Author in Author List
    void AddAuthor(Item data)
    { 
        Scanner input=new Scanner(System.in);
        System.out.print("Enter the name of the author : ");
        data.AddAuthor(input.nextLine());
    }
//Remove Author in Author List
    void RemoveAuthor(Item data)
    { 
        Scanner input=new Scanner(System.in);
        System.out.print("Enter the name of the author : ");
        data.RemoveAuthor(input.nextLine());
    }
//Replace Author in Author List
    void ReplaceAuthor(Item data)
    { 
        Scanner input=new Scanner(System.in);
        System.out.print("Enter the name of the old author : ");
        String old=input.nextLine();
        data.ReplaceAuthor(old);
    }
//Edit Item
    void EditItem(int Id)
    {
        int count=0;
        int x,y,z;
        Scanner input=new Scanner(System.in);
        for(Item data:BooksList)
        {
            if(Id==data.GetId())//if valid id
            {
                 count=1;
                 
                 //Editing for a book
                if(data instanceof Book)
                {
                  
                    /***********Edit Book Title***********/
                    System.out.println("Do you want to edit the title of the book? \n 1. Yes \n 2. No");
                    System.out.print("Choose an option : ");
                    x=input.nextInt();//if yes
                    if(x==1)
                    {
                        EditTitle(data);
                    }
                    else if(x==2)
                    {
                        //Nothing Happens
                    }
                    else
                    {
                        System.out.println("Invalid Input");
                    }
                    /***********Edit Book Author***********/
                    System.out.println("Do you want to edit the author of the book? \n 1. Yes \n 2. No");
                    System.out.print("Choose an option : ");
                    y=input.nextInt();//if yes
                    if(y==1)
                    {
                        EditAuthor(data);
                    }
                    else if(y==2)
                    {
                        //Nothing Happens
                    }
                    else
                    {
                        System.out.println("Invalid Input");
                    }

                    /***********Edit Book Year Of Publication***********/
                    System.out.println("Do you want to edit the year of publication of the book? \n 1. Yes \n 2. No");
                    System.out.print("Choose an option : ");
                    z=input.nextInt();//if yes
                    if(z==1)
                    {
                        EditYearOfPublication(data);
                    }
                    else if(z==2)
                    {
                        //Nothing Happens
                    }
                    else
                    {
                        System.out.println("Invalid Input");
                    }    
                    System.out.println("Editing made Successfully");
                }
                
                
                //Editing for a magazine
                else if(data instanceof Magazine)
                {
                    /***********Edit Magazine Title***********/
                    System.out.println("Do you want to edit the title of the magazine? \n1.Yes \n2.No");
                    System.out.print("Choose an option : ");
                    x=input.nextInt();//if yes
                    System.out.println();
                    if(x==1)
                    {
                        EditTitle(data);
                    }
                    else if(x==2)
                    {
                        //Nothing Happens
                    }
                    else
                    {
                        System.out.println("Invalid Input");
                    }
                     /***********Edit Magazine Company Name***********/
                    System.out.println("Do you want to edit the company name of the magazine? \n1. Yes \n2. No");
                    System.out.print("Choose an option : ");
                    y=input.nextInt();//if yes
                    if(y==1)
                    {
                        EditCompanyName(data);
                    }
                    else if(y==2)
                    {
                        //Nothing Happens
                    }
                    else
                    {
                        System.out.println("Invalid Input");
                    }
                     /***********Edit Magazine AuthorsList***********/
                     while(true)
                     {
                        System.out.println();
                        
                        System.out.println("What do you want to do with Authors List? \n1.Add Author \n2.Remove an Author");
                        System.out.println("3.Replace an Author \n4.No Changes");
                        System.out.print("Choose an option : ");
                        z=input.nextInt();
                        if(z==1)
                        {
                            AddAuthor(data);
                            System.out.println("Updated Authors List : "+data.getAuthorsList());
                        }
                        else if(z==2)
                        {
                            RemoveAuthor(data);
                            System.out.println("Updated Authors List : "+data.getAuthorsList());
                        }
                        else if(z==3)
                        {
                            ReplaceAuthor(data);
                            System.out.println("Updated Authors List : "+data.getAuthorsList());
                        }
                        else if(z==4)
                        {
                           System.out.println("Editing made Successfully");
                           break;
                        }
                        else
                        {
                            System.out.println("Invalid Input");
                        }    
                     }
                }
                
                //Editing for a newspaper
                else if(data instanceof Newspaper)
                {
                    /***********Edit Newspaper Title***********/
                    System.out.println("Do you want to edit the title of the Newspaper? \n 1. Yes \n 2. No");
                    System.out.print("Choose an option : ");
                    x=input.nextInt();//if yes
                    if(x==1)
                    {
                        EditTitle(data);
                    }
                    else if(x==2)
                    {
                        //Nothing Happens
                    }
                    else
                    {
                        System.out.println("Invalid Input");
                    }
                    /***********Edit Newspaper Company Name***********/
                    System.out.println("Do you want to edit the company name of the newspaper? \n 1. Yes \n 2. No");
                    System.out.print("Choose an option : ");
                    y=input.nextInt();//if yes
                    if(y==1)
                    {
                        EditCompanyName(data);
                    }
                    else if(y==2)
                    {
                        //Nothing Happens
                    }
                    else
                    {
                        System.out.println("Invalid Input");
                    }

                    /***********Edit Newspaper Date Of Publication***********/
                    System.out.println("Do you want to edit the date of publication of the Newspaper? \n 1. Yes \n 2. No");
                    System.out.print("Choose an option : ");
                    z=input.nextInt();//if yes
                    if(z==1)
                    {
                        EditDateOfPublication(data);
                    }
                    else if(z==2)
                    {
                        //Nothing Happens
                    }
                    else
                    {
                        System.out.println("Invalid Input");
                    }    
                    System.out.println("Editing made Successfully");
                
                }
            }    
        }
        if(count==0)
        {
        System.out.println("Invalid ID"); 
        }
    }
//Remove item
    void RemoveItem(int ID)
    {
        for(Item data:BooksList)
        {
            if(ID==data.GetId())
            {
             BooksList.remove(data);
             System.out.println("Item Removed Successfully");
             return;
            }    
        }
        System.out.println("Invalid ID"); 
        
    }
//returns booktitle
String Title()
{
    Scanner input=new Scanner(System.in);
    System.out.print("Enter the title : ");
    String Title=input.nextLine();
    return Title;
}
//returns bookauthor
String BookAuthor()
{
    Scanner input=new Scanner(System.in);
    System.out.print("Enter the author of the Book : ");
    String Author=input.nextLine();
    return Author;
}
//returns dateofpublication
String dateofpublication()
{
    Scanner input=new Scanner(System.in);
    String date=ItemDate();
    String month=ItemMonth();
    String year=String.valueOf(ItemYear());
    String dateofpublication=date+"-"+month+"-"+year;
    return dateofpublication;
}
//returns dateofpublication
String CompanyName()
{
    Scanner input=new Scanner(System.in);
    System.out.print("Enter the Company Name : ");
    String CompanyName=input.nextLine();
    return CompanyName;
}
//Add authors
String AddAuthor(int i)
{
    Scanner input=new Scanner(System.in);
    System.out.print("Enter the name of Author "+(i+1)+":");
    String name=input.nextLine();
    return name;
}
//AuthorNames method
List<String> Authornames()
{
    List<String>Authornames=new ArrayList<>();
    Scanner input=new Scanner(System.in);
    System.out.println("How many authors do you want to add? ");
    System.out.print("Enter the quantity of authors : ");
    int quantity=input.nextInt();
    for(int i=0;i<quantity;i++)
    {
        Authornames.add(AddAuthor(i));
    }
    return Authornames;
}

//ItemDate() method
String ItemDate()
{
    int date=0;
    Scanner input=new Scanner(System.in);
    System.out.print("Enter the date of publication (dd): ");
    while(true)
    {
        date =input.nextInt();
        if(date>31||date<1)
        { 
            System.out.print("Invalid Date , Enter Date Again : ");
        }
        else
        {
            return String.valueOf(date);
        }
    }
}
// int ItemMonth() method
String ItemMonth()
{
    int month=0;
    Scanner input=new Scanner(System.in);
    System.out.print("Enter the month of publication (mm): ");
    while(true)
    {
        month =input.nextInt();
        if(month>12||month<1)
        { 
            System.out.print("Invalid Month , Enter Month Again : ");
        }
        else
        {
            return String.valueOf(month);
        }
    }
}
// itemyear method
int ItemYear()
{
    int Year=0;
    Scanner input=new Scanner(System.in);
    System.out.print("Enter the year of publication (yyyy): ");
    while(true)
    {
        Year =input.nextInt();
        if(Year>2023||Year<1)
        { 
            System.out.print("Invalid Year , Enter Year Again : ");
        }
        else
        {
            return Year;
        }
    }
}

//menu to add item
int SelectType()
{
    Scanner input=new Scanner(System.in);
 
    System.out.println("1. Book");
    System.out.println("2. Magazine");
    System.out.println("3. Newspaper");
    System.out.print("Select the Item Type : ");
    int option=input.nextInt();
    return option;
}
//Library Menu
    void LibraryMenu() throws FileNotFoundException
    {
        Scanner input=new Scanner(System.in);
        LoadingFile();//File Loaded
        while(true)
        {
            System.out.println();
            System.out.println("Library Management System Menu : ");
            System.out.println("1. Hot Picks!");
            System.out.println("2. Borrow an Item");
            System.out.println("3. Add Item");
            System.out.println("4. Edit Item");
            System.out.println("5. Delete Item");
            System.out.println("6. View All Items");
            System.out.println("7. View Item by Id");
            System.out.println("8. View Borrowers List");
            System.out.println("9. Exit");
            System.out.print("Select an option from the menu : ");
            int option=input.nextInt();
            if(option==1)//hot picks
            {
               List<Item>SortedList=new ArrayList<>(BooksList.size());//copy of original list
               SortedList.addAll(BooksList);
               Item temp;
               
                //sorting  
                int n=SortedList.size();
                for(int i=1;i<n;++i)
                {
                    Item key1=SortedList.get(i);
                    int key=SortedList.get(i).getPopularityCount();
                    int j=i-1;
                    while(j>=0 && SortedList.get(j).getPopularityCount()<key)
                    {
                        SortedList.set(j+1, SortedList.get(j));
                        j=j-1;
                    
                    }
                    SortedList.set(j+1, key1);
                }
                for(Item a:SortedList) //display sorted list on the basis of popularity count
                {
                    a.DisplayInfo();
                }
            }
            else if(option==2)//borrow an item
            {
                
                System.out.println("Select the Item you want to borrow : ");
                System.out.println("1.Book\n2.Magazine\n3.Newspaper");
                System.out.print("Enter your choice : ");
                int choice=input.nextInt();
                
                if(choice==1)//borrow book
                {
                    int counter=0;
                    List<Integer>IDS=new ArrayList<>();
                    System.out.println("List of Available Books");
                    for(Item a:BooksList)
                    {
                        if(a instanceof Book && !a.getBorrowedStatus())//if borrowedstatus is false
                        {
                            IDS.add(a.GetId());
                            counter++;
                            a.DisplayInfo();
                        }
                    }
                    if(counter==0)
                    {
                        System.out.println("No Available books in the library");
                    }
                    else
                    {
                    System.out.print("\nSelect the Book Id you want to borrow : ");
                    int x=input.nextInt();
                    for(int checkValidID:IDS)
                    {
                        if(checkValidID==x)
                        {
                            counter=100;
                        }
                    }
                    if(counter==100)
                    {
                        Borrower b1=new Borrower();//create borrower object
                        b1.setname();
                        BorrowerList.put(b1.getname(), BooksList.get(x-1).getTitle());//updated hashmap
                        BooksList.get(x-1).setPopularityCount();//popularitycount increased for that book
                        BooksList.get(x-1).setBorrowedStatus();//borrowed status set
                        BooksList.get(x-1).CalculateCost();//calculate cost function
                        System.out.println("Book Borrowed Successfully");
                    }
                    else
                    {
                        System.out.println("Invalid entry");
                    }
                    }
                }
                else if(choice==2)//borrow magazine
                {
                    int counter=0;
                    List<Integer>IDS=new ArrayList<>();
                    System.out.println("List of Available Magazines");
                    for(Item a:BooksList)
                    {
                        if(a instanceof Magazine && !a.getBorrowedStatus())//if borrowedstatus is false
                        {
                            IDS.add(a.GetId());
                            counter++;
                            a.DisplayInfo();
                        }
                    }
                    if(counter==0)
                    {
                        System.out.println("No Available Magazines in the Library");
                    }
                    else
                    {
                    System.out.print("\nSelect the Magazine Id you want to borrow : ");
                    int x=input.nextInt();
                    for(int checkValidID:IDS)
                    {
                        if(checkValidID==x)
                        {
                            counter=100;
                        }
                    }
                    if(counter==100)
                    {
                    Borrower b1=new Borrower();//create borrower object
                    b1.setname();
                    BorrowerList.put(b1.getname(), BooksList.get(x-1).getTitle());//updated hashmap
                    BooksList.get(x-1).setPopularityCount();//popularitycount increased for that book
                    BooksList.get(x-1).setBorrowedStatus();//borrowed status set
                    BooksList.get(x-1).CalculateCost();
                    System.out.println("Magazine Borrowed Successfully");
                    }
                    else
                    {
                        System.out.println("Invalid entry");
                    }
                    }
                }
                else if(choice==3)//borrow newspaper
                {
                    int counter=0;
                    List<Integer>IDS=new ArrayList<>();
                    System.out.println("List of Available Newspaper");
                    for(Item a:BooksList)
                    {
                        if(a instanceof Newspaper && !a.getBorrowedStatus())//if borrowedstatus is false
                        {
                            IDS.add(a.GetId());
                            counter++;
                            a.DisplayInfo();
                        }
                    }
                    if(counter==0)
                    {
                        System.out.println("No Available Newspaper in the Library");
                    }
                    else
                    {
                    System.out.print("\nSelect the Newspaper Id you want to borrow : ");
                    int x=input.nextInt();
                    for(int checkValidID:IDS)
                    {
                        if(checkValidID==x)
                        {
                            counter=100;
                        }
                    }
                    if(counter==100)
                    {
                    Borrower b1=new Borrower();//create borrower object
                    b1.setname();
                    BorrowerList.put(b1.getname(), BooksList.get(x-1).getTitle());//updated hashmap
                    BooksList.get(x-1).setPopularityCount();//popularitycount increased for that book
                    BooksList.get(x-1).setBorrowedStatus();//borrowed status set
                    BooksList.get(x-1).CalculateCost();//calculate cost function
                    System.out.println("Newspaper Borrowed Successfully");
                    }
                    else
                    {
                        System.out.println("Invalid entry");
                    }
                    }
                }
                else
                {
                    System.out.println("Invalid Option");
                }
                    
            }
            else if(option==3)//add item
            {
                int Option=SelectType();
                if(Option==1)//to add book
                {
                String title=Title();
                String author=BookAuthor();
                int year=ItemYear();
                Book newbook=new Book(title,author,year); 
                AddItem(newbook);
                System.out.println("Book Added Successfully");
                }
                else if(Option==2)//to add magazine
                {
                String title=Title();
                String CompanyName=CompanyName();
                List<String>Authornames=Authornames();
                Magazine MagazineData=new Magazine(title,CompanyName,Authornames);
                AddItem(MagazineData);
                System.out.println("Magazine Added Successfully");
                }
                else if(Option==3)//to add newspaper
                {
                String title=Title();
                String dateofpublication=dateofpublication();
                String CompanyName=CompanyName();
                Newspaper newbook=new Newspaper(title,CompanyName,dateofpublication); 
                AddItem(newbook);
                System.out.println("Newspaper Added Successfully");
                }
                else
                {
                    System.out.println("Invalid Input");
                }
                
            }
            else if(option==4)//Edit Item
            {
                if(BooksList.isEmpty())
                {
                    System.out.println("No items in the list");
                }
                else
                {
                    System.out.print("Enter the id of the item you want to edit : ");
                    int id=input.nextInt();
                    EditItem(id);
                }
            }
            else if(option==5)//remove Item by id
            {
                if(BooksList.isEmpty())
                {
                    System.out.println("No items in the list");
                }
                else
                {
                    System.out.print("Enter the id of the item you want to remove : ");
                    int id=input.nextInt();
                    RemoveItem(id);
                }
            }
            else if(option==6)// get details of all items
            {
                if(BooksList.isEmpty())
                {
                    System.out.println("No items in the list");
                }
                else
                {
                    ViewAllItems();
                }
            }
            else if(option==7)//if want to get item details by id of item
            {
                if(BooksList.isEmpty())
                {
                    System.out.println("No items in the list");
                }
                else
                {
                    System.out.print("Enter the id of the item : ");
                    int id=input.nextInt();
                    ViewItemById(id);
                }
            }
            else if(option==8)//view borrowers list
            {
                for (Map.Entry<String, String> entries : BorrowerList.entrySet()) 
                {
                System.out.println("Borrower name: " + entries.getKey() + ", Borrowed Item Name: " + entries.getValue());
                
                }
                if(BorrowerList.isEmpty())
                {
                    System.out.println("Borrower List is Empty");
                }
            }
            else if(option==9)//if you want to exit
            {
                break;
            }
            else //for invalid entry
            {
                System.out.println("Invalid option selected");
                System.out.print("Enter again, ");
            }
        }
    }
    

}


