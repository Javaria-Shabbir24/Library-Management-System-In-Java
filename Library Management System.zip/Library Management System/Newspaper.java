package com.mycompany.assignment1scdparta;

import java.util.Scanner;

class Newspaper extends Item{ 
    //constructor
    public Newspaper(String title,String CompanyName,String DateofPublication)
    {
        super.SetId();
        super.SetTitle(title);
        super.setDateofPublication(DateofPublication);
        super.setCompanyName(CompanyName);
    }
    @Override
     public void DisplayInfo()
    {
        System.out.print("Newspaper");
        super.DisplayInfo();
        System.out.println(" published by company : "+this.getCompanyName()+"("+this.getDateofPublication()+") and Popoularity Count is: "+this.getPopularityCount()); 

    }
     @Override
    public int CalculateCost() {
        Scanner input=new Scanner(System.in);
        this.SetNewspaperCost();
        super.CalculateCost();
        System.out.println(" Rs."+this.getNewspapercost());
        return this.getNewspapercost();
    }
}
