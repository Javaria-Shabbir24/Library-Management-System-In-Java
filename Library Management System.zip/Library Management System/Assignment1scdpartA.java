package com.mycompany.assignment1scdparta;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//Book class
class Book extends Item{
    //constructor
    public Book(String title,String author, int year)
    {
        super.SetId();
        super.SetTitle(title);
        super.SetAuthor(author);
        super.SetYear(year);
    }
    @Override
    public void DisplayInfo()
    {
        System.out.print("Book");
        super.DisplayInfo();
        System.out.println(" written by : "+this.GetAuthor()+"( "+this.GetYear()+")"+" and Popoularity Count is: "+this.getPopularityCount()); 
    }
    @Override
    public int CalculateCost() {
        this.SetBookCost(this.GetId()*10);
        super.CalculateCost();
        System.out.println(" Rs."+this.getBookcost());
        return this.getBookcost();
    }
}
public class Assignment1scdpartA {

    public static void main(String[] args) throws FileNotFoundException {
        // PART A //
        
//Scanner input=new Scanner(System.in);
//        String title;
//        String author;
//        int year;
//        System.out.print("Enter the title of the book : ");
//        title=input.nextLine();
//        System.out.print("Enter the author of the book : ");
//        author=input.nextLine();
//        System.out.print("Enter the year of publication of the book : ");
//        year=input.nextInt();
//        Book obj=new Book(title,author,year);
//        obj.Display();
         
        //PART B
            Library a=new Library();
            a.LibraryMenu();
        
    }
}
