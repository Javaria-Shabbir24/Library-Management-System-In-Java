
package com.mycompany.assignment1scdparta;

import java.util.Scanner;

public class Borrower {
    private String name;
    public Borrower()
    {
        name="";
    }
    public Borrower(String name)
    {
        this.name=name;
    }
    String getname()
    {
        return this.name;
    }
    void setname()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Enter your name : ");
        String name1=input.nextLine();
        this.name=name1;
    }
}
