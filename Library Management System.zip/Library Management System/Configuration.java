
package com.mycompany.assignment1scdparta;
//PART E
public interface Configuration {
    void DisplayInfo();
    int CalculateCost();
}
