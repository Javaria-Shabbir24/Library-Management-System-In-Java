package com.mycompany.assignment1scdparta;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

class Item implements Configuration{
    //java encourages encapsulation that's why private members
    private static int nextId=1;//consistent value for all objects
    private int Id;
    private String title;
    private String author;
    private int year;
    private List<String>AuthorsList=new ArrayList<>();
    private String CompanyName;
    private boolean isBorrowed;
    private int popularityCount;
    private int cost;
    String DateofPublication;
    public Item()//constructor
    {
      Random r=new Random();
      isBorrowed=false;
      popularityCount=r.nextInt(11);
      cost=1;
    }
    @Override
    public void DisplayInfo()
    {
        System.out.print(" Id is : "+this.GetId());
        System.out.print("  ,title : "+this.GetTitle());
    }
    //setter for popularity count
    void setPopularityCount()
    {
        this.popularityCount=popularityCount+1;
    }
    //getter of popularity count
    int getPopularityCount()
    {
        return this.popularityCount;
    }
    //getter borrowed status
    boolean getBorrowedStatus()
    {
        return isBorrowed;
    }
    //setter for borrowed item status
    void setBorrowedStatus()
    {
        isBorrowed=true;
    }
    //setter for Title
    void setDateofPublication(String DateofPublication)
    {
        this.DateofPublication=DateofPublication;
    }
     //setter for getDateofPublication
    String getDateofPublication()
    {
        return this.DateofPublication;
    }
    //setter for Title
    void SetTitle(String title)
    {
        this.title=title;
    }
    //setter for Author
    void SetAuthor(String author)
    {
        this.author=author;
    }
    //setter for year
    void SetYear(int year)
    {
        this.year=year;
    }
    //setter for Id
    void SetId()
    {
       this.Id= nextId++;
    }
    //getter for Id
    int GetId()
    {
        return this.Id;
    }
    //getter for title
    String GetTitle()
    {
        return this.title;
    }
    //getter for author
    String GetAuthor()
    {
        return this.author;
    }
    //getter for year
    int GetYear()
    {
        return this.year;
    }
    //add an author in authors list
    void AddAuthor(String a)
    {
         this.AuthorsList.add(a);
    }
    //remove an author in authors list
    void RemoveAuthor(String a)
    {
        int count=-1;
        System.out.println(a);
        for(String x:AuthorsList)
        {
            count++;
            if(x.toLowerCase().equals(a.toLowerCase()))
            {
                AuthorsList.remove(count);
                count=100;
                break;
            }
        }
        if(count!=100)
        {
            System.out.println("Invalid Entry");
        }
    }
    //replace an author name in authors list
    void ReplaceAuthor(String oldname)
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Enter the name of the new author :");
        String newname=input.nextLine();
        int count=-1;
        for(int i=0;i<AuthorsList.size();i++)
        {
            String x=AuthorsList.get(i);
            if(x.toLowerCase().equals(oldname.toLowerCase()))
            {
                AuthorsList.set(i, newname);
                count=100;
                break;
            }
        }
        if(count!=100)
        {
            System.out.println("Invalid Entry");
        }
    }
    //get authors list
    List<String> getAuthorsList()
    {
        return this.AuthorsList;
    }
     //setter for authorslist
    void setAuthorsList(List<String> AuthorsList)
    {
        this.AuthorsList.addAll(AuthorsList);
    }
    //setter for company name
    void setCompanyName(String CompanyName)
    {
        this.CompanyName=CompanyName;
    }
    //getter for title
    String getTitle()
    {
        return this.title;
    }
    //getter for company name
    String getCompanyName()
    {
        return this.CompanyName;
    }
    //setter for Book cost
    void SetBookCost(int cost)
    {
        final int totalCost=cost+(20/100*cost)+200;//given formula
        this.cost=totalCost;
    }
    //getter for Book Cost
    int getBookcost()
    {
        return cost;
    }
    //setter for Magazine Cost
    void SetMagazineCost(int cost)
    {
        final int totalCost=cost*this.getPopularityCount();//given formula
        this.cost=totalCost;
    }
     //getter for Magazine Cost
    int getMagazinecost()
    {
        return cost;
    }
      //setter for Newspaper Cost
    void SetNewspaperCost()
    {
        final int totalCost=10+5;//given formula
        this.cost=totalCost;
    }
     //getter for Newspaper Cost
    int getNewspapercost()
    {
        return cost;
    }
    @Override
    public int CalculateCost() {
        System.out.print("Total Bill : ");
        return this.cost;
    }
}
